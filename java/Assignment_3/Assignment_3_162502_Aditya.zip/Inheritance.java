package Assignment_3;

import java.util.Scanner;

class Animal {
    void walk() { 
      System.out.println("I am walking"); 
    }
}

class Bird extends Animal {
    void fly() { 
      System.out.println("I am flying"); 
    }
}

class Shape {
    double getArea() { 
      return 0; 
    }
}

class Rectangle extends Shape {
    double width, length;
    Rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }
    @Override
    double getArea() { return width * length; }
}

class Circle extends Shape {
    double radius;
    Circle(double radius) { 
      this.radius = radius; 
    }
    @Override
    double getArea() { 
      return Math.PI * radius * radius; 
    }
}

class Person {
    String name;
    int age;
    Person(String name, int age) {
        this.name = name;
        this.age = age;
        System.out.println("Person constructor called");
    }
}

class StaffMember extends Person {
    int employeeId;
    StaffMember(String name, int age, int employeeId) {
        super(name, age);
        this.employeeId = employeeId;
        System.out.println("StaffMember constructor called");
    }
    void displayDetails() {
        System.out.println("ID: " + employeeId + " | Name: " + name + " | Age: " + age);
    }
}

public class Inheritance {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n===== MENU =====");
            System.out.println("1. Basic Inheritance (Bird)");
            System.out.println("2. Method Overriding (Shapes)");
            System.out.println("3. Use of super Keyword (Staff)");
            System.out.println("4. Management System (Payrolls)");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Bird eagle = new Bird();
                    eagle.walk();
                    eagle.fly();
                    break;

                case 2:
                    System.out.println("1. Rectangle\n2. Circle");
                    int choice_shape = scanner.nextInt();
                    if (choice_shape == 1) {
                        System.out.print("Width: "); double w = scanner.nextDouble();
                        System.out.print("Length: "); double l = scanner.nextDouble();
                        System.out.println("Area: " + new Rectangle(w, l).getArea());
                    } else {
                        System.out.print("Radius: "); double r = scanner.nextDouble();
                        System.out.println("Area: " + new Circle(r).getArea());
                    }
                    break;

                case 3:
                    StaffMember sm = new StaffMember("Chandragupt", 30, 101);
                    sm.displayDetails();
                    break;

                case 4:
                    Employee[] staff = new Employee[3];
                    staff[0] = new Manager("Alice", 80000, 15000);
                    staff[1] = new Developer("Bob", 60000, 5);
                    staff[2] = new Employee("Charlie", 50000);

                    System.out.println("\n--- Payrolls ---");
                    for (Employee e : staff) {
                        System.out.println(e.name + ": " + e.getSalary());
                    }
                    break;

                case 0:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid Choice...");
            }
        } while (choice != 0);
        scanner.close();
    }
}
